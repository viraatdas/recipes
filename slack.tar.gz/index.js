module.exports = Franz => Franz;
